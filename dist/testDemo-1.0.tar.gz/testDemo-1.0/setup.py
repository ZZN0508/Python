# -*- coding: utf-8 -*-
from distutils.core import setup
setup(
    name='testDemo',
    version='1.0',
    author='zzn',
    author_email='1933230368@qq.com',
    package=['learn'],
)